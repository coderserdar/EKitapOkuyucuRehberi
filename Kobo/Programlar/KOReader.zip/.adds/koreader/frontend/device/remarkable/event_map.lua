return {
    [102] = "Home",
    [105] = "LPgBack",
    [106] = "RPgFwd",
    [116] = "Power",
}
-- TODO libremarkable has 143 as "wakeup" - don't know what that corresponds to?
