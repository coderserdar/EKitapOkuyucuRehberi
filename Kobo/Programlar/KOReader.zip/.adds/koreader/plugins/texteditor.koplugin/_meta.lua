local _ = require("gettext")
return {
    name = "texteditor",
    fullname = _("Text editor"),
    description = _([[A basic text editor for making small changes to plain text files.]]),
}
