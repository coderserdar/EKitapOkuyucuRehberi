local _ = require("gettext")
return {
    name = "autostandby",
    fullname = _("Auto Standby"),
    description = _([[Put into standby on no input, wake up from standby on UI input]]),
}
