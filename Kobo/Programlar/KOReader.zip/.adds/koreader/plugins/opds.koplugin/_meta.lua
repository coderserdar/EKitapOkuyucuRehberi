local _ = require("gettext")
return {
    name = "opds",
    fullname = _("OPDS"),
    description = _([[OPDS allows you to download books from online catalogs.]]),
}
