local _ = require("gettext")
return {
    name = "calibre",
    fullname = _("Calibre"),
    description = _([[Integration with calibre. Send documents from calibre library via Wi-Fi and search calibre metadata.]]),
}
