local _ = require("gettext")
return {
    name = "terminal",
    fullname = _("Terminal emulator"),
    description = _([[KOReader's terminal emulator]]),
}
