local _ = require("gettext")
return {
    name = "coverbrowser",
    fullname = _("Cover browser"),
    description = _([[Alternative display modes for file browser and history.]]),
}
