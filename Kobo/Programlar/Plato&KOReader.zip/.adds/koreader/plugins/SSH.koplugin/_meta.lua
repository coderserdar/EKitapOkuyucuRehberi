local _ = require("gettext")
return {
    name = "SSH",
    fullname = _("SSH"),
    description = _([[Connect and transfer files to the device using SSH.]]),
}
