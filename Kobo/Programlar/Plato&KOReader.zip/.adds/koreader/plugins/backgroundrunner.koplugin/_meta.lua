local _ = require("gettext")
return {
    name = "backgroundrunner",
    fullname = _("Background runner"),
    description = _([[Service to other plugins: allows tasks to run regularly in the background.]]),
}
