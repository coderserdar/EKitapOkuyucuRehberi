# Don't set the framebuffer's depth.
# unset PLATO_SET_FRAMEBUFFER_DEPTH

# Don't convert StarDict dictionaries.
# unset PLATO_CONVERT_DICTIONARIES

# Disable hyphenation.
# [ -d hyphenation-patterns ] && rm -rf hyphenation-patterns
